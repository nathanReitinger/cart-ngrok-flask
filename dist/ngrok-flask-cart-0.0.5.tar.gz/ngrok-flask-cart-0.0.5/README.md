# flask-ngrok-CART
An offshoot of [flask-ngrok](https://github.com/gstaff/flask-ngrok) (see also [flask-ngrok2](https://github.com/MohamedAliRashad/flask-ngrok2), [flask-ngrok3](https://github.com/Partycode/flask-ngrok3)) for making demo Flask apps from personal machine.

## Installation

```bash
pip3 install ngrok_flask_cart
```
